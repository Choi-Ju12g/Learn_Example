const body = document.querySelector("body");
const h1 = document.createElement("h2");

body.appendChild(h1);
h1.innerText = "Hello!!";

function handleWindow() {
  if (window.innerWidth < 500) {
    h1.innerText = "Small size window";
    body.style.backgroundColor = "orange";
  } else if (window.innerWidth > 1000) {
    h1.innerText = "Large size window";
    body.style.backgroundColor = "blue";
  } else {
    h1.innerText = "Medium size window";
    body.style.backgroundColor = "pink";
  }
}

window.addEventListener("resize", handleWindow);
