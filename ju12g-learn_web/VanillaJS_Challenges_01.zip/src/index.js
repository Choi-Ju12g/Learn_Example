const body = document.querySelector("body");
const h1 = document.createElement("h2");

body.appendChild(h1);
h1.innerText = "Hello!!";

let windowSize = window.
